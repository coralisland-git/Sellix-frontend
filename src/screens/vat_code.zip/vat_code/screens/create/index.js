import screen from './screen'
import * as actions from './actions'

export default {
  screen,
  actions
}